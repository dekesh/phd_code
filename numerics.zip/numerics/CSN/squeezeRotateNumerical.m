(* ::Package:: *)

BeginPackage["squeezeRotateNumerical`"]


listDataFiles::usuage = "
listDataFiles[directory, pattern]
Returns a list of files from 'directory' that match 'pattern'
"

getAlphaThetaPhiFromMatrix::usuage = 
"
getAlphaThetaPhiFromMatrix[U]

Returns the list {\[Alpha], \[Theta], \[Phi]} from a 2x2 matrix U. Where 
U = cosh(\[Alpha]) + sinh(\[Alpha]) [n1\[Sigma]1 + i*n2\[Sigma]1 + n3\[Sigma]3]
and 
n3 = cosh(2 \[Theta]) sin(2 \[Phi])
n1 = cosh(2 \[Theta]) cos(2 \[Phi])
n2 = sinh(2 \[Theta])
Note that \[Alpha]>=0, -inf < \[Theta] < inf, -\[Pi]/2 < \[Phi] < \[Pi]/2
";


generateRandomSqueezeRotate::usuage = 
"
generateRandomSqueezeRotate[ lambda \[Rule] 1, maxPhi \[Rule] None, minPhi \[Rule] None, numberOfTimeSteps \[Rule] 1, numberOfRealizations\[Rule]1]

Generates a series of realizations of random rotation and squeezing.

----------
Input parameters->(defaults): 
lambda: squeezing paramerter. {{Exp[lambda],0},{0,Exp[-lambda]}}
maxPhi: maximum rotation angle
minPhi: minimum rotation angle, if not given then -maxPhi
numberOfTimeSteps: number of time steps of each 'run'.
numberOfRealization:  total number of realizations.

Output:
a list of size 'numberOfRealization', where each element containts a list of 2x2 matrices of size 
'numberOfTimeSteps'+1. Each such list is {1, a, a^2, ..}, where 'a' is a realization of RotationMatrix[\[Theta]].SqueezeMatrix[\[Lambda]].
And \[Theta] ~ [minPhi, maxPhi], and SqueezeMatrix[\[Lambda]] = {{Exp[x],0},{0,Exp[-x]}}
";

funcOnRealizations::usuage = 
"
funcOnRealizations[func, elementList]

Apply  func on all the second levels of elementList
(Actually it just returns Map[func, elementList, {2}])
--------------
Input:
func : a function
elementList : a list of lists, such as { { l11, l12, ... }, {l21, l22, .. } ... }.

Output:
{ { func[l11], func[l12], ... }, {func[l21], func[l22], .. } ... }.
";

histogramOnRealizations::usuage = 
"
histogramOnRealizations[elementList, timeIndexList:Null]

Returns the  histogram of realizations, by default returns the historgram of the last time step,
but can returns a few if timeIndexList is given.
-----------------------------
Input:
elementList: a list of lists, { { l11, l12, ... }, {l21, l22, .. } ... }, so hat lij are numbers
timeIndexList: a list of numbers

Output:
A histogram of Transpose[elementList][[i]], Where i is given by timeIndexList. If timeIndexList is a list of numbers, then returns a
few such histograms. Each histogram is labeled by it's time
";
	

saveRealizationsToFile::usuage = 
"
saveRealizationsToFile[realizations]
saveRealizationsToFile[realizations, fileName]

Save symbol 'realizations' to memory.
If fileName is not supplied, save to deafult file
";

loadRealizationsFromFile::usuage = 
"
loadRealizationsToFile[]
loadRealizationsToFile[fileName]

Load symbol from memory. Usuage:
realizations = loadRealizationsToFile[]

If fileName is not supplied, load from deafult file
";

Begin["Private`"]


Options[generateRandomSqueezeRotate] ={
lambda -> 1,
maxPhi ->Null,
minPhi ->Null,
numberOfTimeSteps -> 1,
numberOfRealizations->1,
timeList->{}
};

generateRandomSqueezeRotate[OptionsPattern[]]:=Module[
{
lambdaValue = OptionValue[lambda],
maxPhi=OptionValue[maxPhi],
minPhi=OptionValue[minPhi],
numberOfTimeSteps = OptionValue[numberOfTimeSteps],
numberOfRealizations = OptionValue[numberOfRealizations],
timeList = OptionValue[timeList],
rotation, squeeze, SqueezeRotation,
matrixToMultiply, realizeOneRun,totalRealizations
},
If[maxPhi==minPhi, Return[]];
If[minPhi === Null, minPhi = -maxPhi];

(* Define squeeze and rotation matrices *)
rotation[x_]:=RotationMatrix[x];
squeeze[x_]:={{Exp[x],0},{0,Exp[-x]}};
SqueezeRotation [a_,b_]:= rotation[b] . squeeze[a]; (* first squeeze then rotate *)

matrixToMultiply := SqueezeRotation[lambdaValue,RandomReal[{minPhi,maxPhi}]];
(*matrixToMultiply = 2*IdentityMatrix[2]*) (* Can be used to debug*)
If[timeList === {},
realizeOneRun:=Module[{},
(* Create the matrices: {1, a, a^2, a^3, .., a^(numberOfTimeSteps+1)*)
NestList[# .matrixToMultiply& ,
IdentityMatrix[2],numberOfTimeSteps]];
,
realizeOneRun:=Module[{},
(* Create the matrices: {1, a, a^2, a^3, .., a^(numberOfTimeSteps+1)*)
NestList[# .matrixToMultiply& ,
IdentityMatrix[2],numberOfTimeSteps][[timeList]] ];
];
(* totalRealizations = 
{
{1, a, a^2, ..},
{1, a, a^2, ..},
... Where each relaization is in a new list
 *)
(*totalRealizations[x_,y_] := Table[(#.{x,y})&/@realizeOneRun,{numberOfRealizations}];*)
totalRealizations= Table[realizeOneRun,{numberOfRealizations}]
]

funcOnRealizations[func_, elementList_]:=Module[{},
Map[func, elementList, {2}]
]


(* Returns the list {\[Alpha], \[Phi], \[Theta]} a 2x2 matrix U. Where 
U = cosh(\[Alpha]) + sinh(\[Alpha]) [n1\[Sigma]1 + i*n2\[Sigma]1 + n3\[Sigma]3]
and 
n3 = cosh(2 \[Theta]) sin(2 \[Phi])
n1 = cosh(2 \[Theta]) cos(2 \[Phi])
n2 = sinh(2 \[Theta])
 *)
getAlphaThetaPhiFromMatrix [matrix_]:=
Module[{alpha, phi, theta, cosPhi, sinPhi},
alpha = ArcCosh[Tr[matrix]/2];
If[alpha === 0, Return[{0,0,0}]];
theta = ArcSinh[Tr[-I*PauliMatrix[2].matrix]/(2*Sinh[alpha])]/2;
cosPhi = Tr[PauliMatrix[1].matrix]/(2*Cosh[2 theta]*Sinh[alpha]);
sinPhi = Tr[PauliMatrix[3].matrix]/(2*Cosh[2 theta]*Sinh[alpha]);
{alpha, theta, ArcTan[cosPhi, sinPhi]/2}
]


Options[histogramOnRealizations] = {
bspec -> {0.1},
hspec->"PDF",
chartLegends->Null,
plotLabel->"Histogram"
}



histogramOnRealizations[elementList_, timeIndexList_:Null, OptionsPattern[]]:=Module[{elListTr = Transpose[elementList], timeIndexTmp = timeIndexList},
If[timeIndexTmp === Null, timeIndexTmp = Length[elListTr]];
If[timeIndexTmp === "All",  timeIndexTmp = Table[i,{i,1,Length[elListTr]}]];
(* Switch first two places, because for some reason these colors are inverted in historgram and plot (at least for this version) *)
Histogram[elListTr[[timeIndexTmp]], OptionValue[bspec], OptionValue[hspec],PlotLabel->OptionValue[plotLabel], ChartLegends->OptionValue[chartLegends]]
]

Options[saveRealizationsToFile]={
verbose->False,
appendDir->""
};

saveRealizationsToFile[realizations_, fileName_:"realizationsData.mx", OptionsPattern[]]:=Module[{
finalPath = NotebookDirectory[] <> "/data/"<>OptionValue[appendDir]<>"/"<>fileName},
globalRealizationsData = realizations;
Export[finalPath, realizations];
If[OptionValue[verbose], Print["File saved:",finalPath]];
]

loadRealizationsFromFile[fileName_:"realizationsData.mx"]:=Module[{file = NotebookDirectory[] <> "data/"<>fileName},
(*Print[file];*)
Import[file]
]

(* List all files in directory that match patterns*)
listDataFiles[directory_, pattern_]:=Module[{files},
SetDirectory[directory];
files = FileNames[pattern];
ResetDirectory[];
files
]


Options[drawRealizations]={

};

drawRealizations


End[]
EndPackage[]



